import React, { useState } from 'react';
import { Info, Plus } from 'lucide-react';
import { motion } from 'motion/react';

export const SourceManagement: React.FC = () => {
  const [url, setUrl] = useState('');

  return (
    <div className="reading-column py-12">
      <motion.div 
        initial={{ opacity: 0, x: -10 }}
        animate={{ opacity: 1, x: 0 }}
        className="mb-16"
      >
        <span className="text-[10px] font-bold text-primary uppercase tracking-[0.5em] mb-4 block">Assignment // 03</span>
        <h1 className="text-7xl font-black text-black mb-6 tracking-tighter uppercase leading-[0.85]">Source<br/>Control</h1>
        <p className="text-body-lg text-black/60 italic max-w-md">
          Configure your news engine. Add new stream endpoints or reorganize your existing editorial subscriptions.
        </p>
      </motion.div>

      <div className="flex flex-col gap-12">
        <motion.div 
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white border border-black p-10 brutalist-shadow"
        >
          <h2 className="text-2xl font-black uppercase tracking-tighter mb-8">Add New Subscription</h2>
          <div className="flex flex-col gap-6">
            <div>
              <label className="text-[10px] font-bold uppercase tracking-widest text-black/40 block mb-3">Endpoint URL</label>
              <input 
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://chroma.studio/rss"
                className="w-full bg-background border border-black p-4 text-body-md font-bold focus:bg-white focus:outline-none transition-all"
                type="text"
              />
            </div>
            <button className="bg-black text-white py-5 px-8 text-xl font-black uppercase tracking-widest hover:bg-primary active:translate-x-1 active:translate-y-1 transition-all">
              Validate & Sync
            </button>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="bg-white border-2 border-black border-dashed p-8 flex gap-6 items-start"
        >
          <div className="w-12 h-12 bg-primary flex items-center justify-center shrink-0 border border-black shadow-brutalist-small">
            <Info size={24} className="text-white" />
          </div>
          <p className="text-sm font-bold uppercase tracking-wider leading-relaxed opacity-60">
            CHROMA STUDIO SUPPORTS RSS 2.0, ATOM 1.0, AND JSON FEED FORMATS. SECURE HANDSHAKE IS MANDATORY FOR ALL ENDPOINTS.
          </p>
        </motion.div>

        <div className="mt-12">
          <h3 className="text-[10px] font-black text-black uppercase tracking-[0.3em] mb-6 inline-block border-b-2 border-primary pb-2">Active Transmissions</h3>
          <div className="grid grid-cols-1 gap-4">
            {['The Verge', 'Wired', 'TechCrunch', 'Hacker News'].map((source) => (
              <div key={source} className="flex items-center justify-between p-6 bg-white border border-black hover:shadow-brutalist-small transition-all cursor-pointer">
                <span className="text-lg font-black uppercase tracking-tighter">{source} // LIVE</span>
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
