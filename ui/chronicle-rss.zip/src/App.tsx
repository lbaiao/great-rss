/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { View, Article } from './types';
import { Sidebar } from './components/Sidebar';
import { DashboardHeader } from './components/DashboardHeader';
import { Dashboard } from './components/Dashboard';
import { Reader } from './components/Reader';
import { SourceManagement } from './components/Sources';
import { MOCK_ARTICLES } from './constants';
import { LayoutDashboard, BookOpen, Rss, Settings } from 'lucide-react';

export default function App() {
  const [view, setView] = useState<View>(View.DASHBOARD);
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);

  const handleArticleClick = (article: Article) => {
    setSelectedArticle(article);
    setView(View.READER);
  };

  const renderContent = () => {
    switch (view) {
      case View.DASHBOARD:
        return <Dashboard onArticleClick={handleArticleClick} />;
      case View.READER:
        return selectedArticle ? (
          <Reader article={selectedArticle} onBack={() => setView(View.DASHBOARD)} />
        ) : (
          <Dashboard onArticleClick={handleArticleClick} />
        );
      case View.SOURCES:
        return <SourceManagement />;
      case View.HELP:
        return (
          <div className="reading-column py-12">
            <h1 className="text-display-lg font-bold mb-4">Help & Support</h1>
            <p className="text-body-lg">Documentation and support resources coming soon.</p>
          </div>
        );
      case View.ARCHIVE:
        return (
          <div className="reading-column py-12">
            <h1 className="text-display-lg font-bold mb-4">Archive</h1>
            <p className="text-body-lg">Saved articles will appear here.</p>
          </div>
        );
      default:
        return <Dashboard onArticleClick={handleArticleClick} />;
    }
  };

  return (
    <div className="min-h-screen">
      <Sidebar activeView={view} onViewChange={setView} />
      
      <div className="md:ml-64 flex flex-col min-h-screen">
        <DashboardHeader />
        
        <main className="mt-16 px-4 md:px-margin-desktop min-h-[calc(100vh-64px)] overflow-y-auto">
          {renderContent()}
        </main>
      </div>

      {/* Mobile Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-black flex justify-around items-center h-16 z-50">
        <button 
          onClick={() => setView(View.DASHBOARD)}
          className={`flex flex-col items-center justify-center gap-1 transition-colors ${view === View.DASHBOARD ? 'text-primary' : 'text-black/40'}`}
        >
          <LayoutDashboard size={18} strokeWidth={view === View.DASHBOARD ? 3 : 2} />
          <span className="text-[10px] font-bold uppercase tracking-widest leading-none mt-1">Dash</span>
        </button>
        <button 
          onClick={() => setView(View.READER)}
          className={`flex flex-col items-center justify-center gap-1 transition-colors ${view === View.READER ? 'text-primary' : 'text-black/40'}`}
        >
          <BookOpen size={18} strokeWidth={view === View.READER ? 3 : 2} />
          <span className="text-[10px] font-bold uppercase tracking-widest leading-none mt-1">Read</span>
        </button>
        <button 
          onClick={() => setView(View.SOURCES)}
          className={`flex flex-col items-center justify-center gap-1 transition-colors ${view === View.SOURCES ? 'text-primary' : 'text-black/40'}`}
        >
          <Rss size={18} strokeWidth={view === View.SOURCES ? 3 : 2} />
          <span className="text-[10px] font-bold uppercase tracking-widest leading-none mt-1">Source</span>
        </button>
        <button 
          className="flex flex-col items-center justify-center gap-1 text-black/40 transition-colors"
        >
          <Settings size={18} />
          <span className="text-[10px] font-bold uppercase tracking-widest leading-none mt-1">Set</span>
        </button>
      </nav>
    </div>
  );
}
