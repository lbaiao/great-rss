export type Article = {
  id: string;
  source: string;
  title: string;
  snippet: string;
  content: string;
  author: string;
  date: string;
  category: string;
  readTime: string;
  timeAgo: string;
  unread: boolean;
  imageUrl?: string;
  tags: string[];
};

export type Feed = {
  id: string;
  url: string;
  name: string;
  category: string;
};

export enum View {
  DASHBOARD = 'DASHBOARD',
  READER = 'READER',
  SOURCES = 'SOURCES',
  HELP = 'HELP',
  ARCHIVE = 'ARCHIVE'
}
