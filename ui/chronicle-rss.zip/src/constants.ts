import { Article } from './types';

export const MOCK_ARTICLES: Article[] = [
  {
    id: '1',
    source: 'The Verge',
    title: 'The New Architecture of Digital Typography',
    snippet: 'Exploring how modern web technologies are finally enabling a level of typographic control previously reserved for high-end print magazines and editorial design.',
    content: `
      <p>In an era dominated by soft gradients and rounded corners, a new movement is emerging. Designers are looking back at the mid-century functionalism of Swiss design and the uncompromising honesty of Brutalist architecture. This isn't just a nostalgic trend; it's a reaction against the clutter of the modern web.</p>
      <p>The core tenet of the International Typographic Style was simple: **content is primary**. Every line, every border, and every point of whitespace must serve the legibility of the information. For RSS readers, this philosophy is the holy grail. We are moving away from the "infinite scroll" of dopamine-driven feeds toward a "finishable" reading experience.</p>
      
      <blockquote>"Design is not for philosophy, it's for life. But life requires structure to be understood."<br/>— MAX BILL, 1952</blockquote>

      <h3>The 8px Baseline Grid</h3>
      <p>A grid is more than a set of lines; it's a rhythmic structure for the eye. By adhering to a strict 8px baseline, we ensure that every element—from the line height of a paragraph to the padding of a button—feels intentional. This mathematical precision creates a sense of calm and professionalism that "eyeballed" layouts simply cannot replicate.</p>

      <div class="key-takeaways">
        <h4>Key Takeaways</h4>
        <ul>
          <li>Prioritize information density without decorative noise.</li>
          <li>Use whitespace as a structural component, not a gap.</li>
          <li>High-contrast typography is the most effective UI tool.</li>
        </ul>
      </div>

      <p>As we continue to build Chronicle, we remain committed to these principles. Our goal is to provide a lens, not a distraction. The reader view you see here is the result of hundreds of hours of typographic refinement, ensuring that the only thing between you and the author's intent is a few pixels of light.</p>
    `,
    author: 'Elias Thorne',
    date: 'Oct 24, 2023',
    timeAgo: '12m ago',
    category: 'Architecture',
    readTime: '8 min read',
    unread: true,
    tags: ['Typography', 'Swiss Style', 'RSS']
  },
  {
    id: '2',
    source: 'Wired',
    title: 'Quantum Computing: A Blueprint for the Future',
    snippet: 'New breakthroughs in cryogenic cooling systems are bringing us closer to scalable quantum processors that could redefine computational limits.',
    content: '<p>Deep technical content about quantum computing...</p>',
    author: 'Sarah Jenkins',
    date: 'Oct 23, 2023',
    timeAgo: '1h ago',
    category: 'Technology',
    readTime: '12 min read',
    unread: false,
    tags: ['Quantum', 'Tech', 'Hardware']
  },
  {
    id: '3',
    source: 'TechCrunch',
    title: 'The Rise of Minimalist Interface Design',
    snippet: 'Why users are increasingly moving away from feature-heavy social platforms toward streamlined, purpose-built information tools.',
    content: '<p>Analysis of minimalist design trends...</p>',
    author: 'Marco Rossi',
    date: 'Oct 23, 2023',
    timeAgo: '3h ago',
    category: 'Design',
    readTime: '6 min read',
    unread: true,
    tags: ['Minimalism', 'UI/UX']
  },
  {
    id: '4',
    source: 'Hacker News',
    title: 'Rust for the Modern Web: A Case Study',
    snippet: 'How a small team migrated their entire RSS processing pipeline to Rust, achieving 10x performance improvements and significantly lower memory usage.',
    content: '<p>A deep dive into using Rust for backend systems...</p>',
    author: 'Alex Chen',
    date: 'Oct 22, 2023',
    timeAgo: '5h ago',
    category: 'Science',
    readTime: '15 min read',
    unread: true,
    tags: ['Rust', 'Back-end', 'Performance']
  }
];

export const MOCK_FEEDS = [
  { id: '1', url: 'https://theverge.com/rss', name: 'The Verge', category: 'Technology' },
  { id: '2', url: 'https://wired.com/feed', name: 'Wired', category: 'Technology' }
];
